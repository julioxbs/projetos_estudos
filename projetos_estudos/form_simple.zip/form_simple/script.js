const form = document.getElementById('my-form');
const username = document.getElementById('username');
const email = document.getElementById('email');
const password = document.getElementById('password');
const password2 = document.getElementById('password2');

function inputError(input,message) {
    const formControl = input.parentElement;
    formControl.className = 'form-control error';
    const small = formControl.querySelector('small')
    small.innerHTML = message;
}

function inputSuccess(input) {
    const formControl = input.parentElement;
    formControl.className = 'form-control success';
}

function cheackEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

form.addEventListener('submit', function(e) {
    e.preventDefault();

    if(username.value === '') {
        inputError(username, `<i class="fas fa-exclamation-circle">` + 'O usuário é necessário.')
    } else {
        inputSuccess(username)
    }
    if(email.value === '') {
        inputError(email, `<i class="fas fa-exclamation-circle">` + 'Email é necessário.')
    } else if (!cheackEmail(email.value)){
        inputError(email, `<i class="fas fa-exclamation-circle">` + 'Escreva um email valido.')
    } else {
        inputSuccess(email)
    }
    if(password.value === '') {
        inputError(password, `<i class="fas fa-exclamation-circle">` + 'A senha é obrigatoria.')
    } else {
        inputSuccess(password)
    }
    if(password2.value === '') {
        inputError(password2, `<i class="fas fa-exclamation-circle">` + 'A confirmação da senha é obrigatória.')
    } else if (password.value !== password2.value) {
        inputError(password2, `<i class="fas fa-exclamation-circle">` + 'A senha não condiz.')
    } else {
        inputSuccess(password2)
    }
});